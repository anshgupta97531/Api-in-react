import { useState } from 'react';
import './App.css';

function App() {

  //API
  const [user, setUser] = useState(null); // Store a single user object

  
  // API 
  const getData = async () => {
    try {
      const response = await fetch('https://randomuser.me/api/');
      const data = await response.json();
      setUser(data.results[0]); // Update state with the first user from the results
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <>
    {/*Api*/}
    <div className="App">
      <h1>User Information</h1>
      {user ? (
        <div className="user-info">
          <img src={user.picture.large}  className="profile-pic" />
          <p><strong>Name:</strong> {user.name.first} {user.name.last}</p>
          <p><strong>Email:</strong> {user.email}</p>
        </div>
      ) : (
        <p>No user data available</p>
      )}
      <button onClick={getData}>Get data</button>
    </div>


    

    


    </>
    
  );
}

export default App;
